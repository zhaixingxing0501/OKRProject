//
//  ZLaunchViewManager.m
//  ZLaunchViewDemo
//
//  Created by zhaixingxing on 2020/6/2.
//  Copyright © 2020 zhaixingxing. All rights reserved.
//

#import "ZLaunchViewManager.h"
#import "ZLaunchView.h"
#import "UIImage+ZLaunchImage.h"
#import "UIImageView+WebCache.h"
#import "AFNetworkReachabilityManager.h"

@interface ZLaunchViewManager ()

@property (nonatomic, weak) ZLaunchView *launchView;

@property (nonatomic, strong) dispatch_source_t timer;

@end
 
static ZLaunchViewManager *_launchwManager = nil;

@implementation ZLaunchViewManager


+ (instancetype)launchViewManger {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _launchwManager = [[ZLaunchViewManager alloc] init];
    });
    return _launchwManager;
}

-(void)showView:(UIView *)view
{
    self.frame=view.bounds;
    [view addSubview:self];
    [self addADLaunchView];
    [self loadData];
}

- (void)NetworkMonitoring
{
    //1.创建网络状态监测管理者
    AFNetworkReachabilityManager *manger = [AFNetworkReachabilityManager sharedManager];
    //2.开启监听
    [manger startMonitoring];
    //3.监听网络状态的改变
    [manger setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        /*
         AFNetworkReachabilityStatusUnknown = -1,
         AFNetworkReachabilityStatusNotReachable = 0,
         AFNetworkReachabilityStatusReachableViaWWAN = 1,
         AFNetworkReachabilityStatusReachableViaWiFi = 2,
         */
        switch (status) {
            case AFNetworkReachabilityStatusUnknown:
                NSLog(@"未知");
                break;
            case AFNetworkReachabilityStatusNotReachable:
                NSLog(@"此时没有网络");
                break;
            case AFNetworkReachabilityStatusReachableViaWWAN:
                NSLog(@"移动网络");
                break;
            case AFNetworkReachabilityStatusReachableViaWiFi:
                NSLog(@"WiFi");
                break;
            default:
                break;
        }
    }];
}

- (void)dataCacheWithDic:(NSDictionary *)dic {
    
    NSString * path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)lastObject];
    NSString * pathName = [path stringByAppendingString:@"launch.data"];
    [NSKeyedArchiver archiveRootObject:dic toFile:pathName];
}



- (void)addADLaunchView
{
    ZLaunchView *adLaunchView = [[ZLaunchView alloc]init];
    adLaunchView.skipBtn.hidden = YES;
    adLaunchView.launchImageView.image = [UIImage getLaunchImage];
    adLaunchView.frame=self.bounds;
    [adLaunchView.skipBtn addTarget:self action:@selector(skipADAction) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:adLaunchView];
    _launchView = adLaunchView;
}
- (void)loadData
{
    
//    if ( _adModel.launchUrl&&_adModel.launchUrl.length>0) {
        [self showADImageWithURL:[NSURL URLWithString:@"http://d.hiphotos.baidu.com/image/pic/item/f7246b600c3387444834846f580fd9f9d72aa034.jpg"]];
        UITapGestureRecognizer * tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(pushAdController)];
        [_launchView addGestureRecognizer:tap];
//    }else{
//        [self dismissController];
//    }
}
- (void)showADImageWithURL:(NSURL *)url
{
    __weak typeof(self) weakSelf = self;
    [_launchView.adImageView  sd_setImageWithURL:url placeholderImage:nil options:SDWebImageRetryFailed completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        // 启动倒计时
        [weakSelf scheduledGCDTimer];
    } ];
}
- (void)showSkipBtnTitleTime:(int)timeLeave
{
    NSString *timeLeaveStr = [NSString stringWithFormat:@"跳过 %ds",timeLeave];
    [_launchView.skipBtn setTitle:timeLeaveStr forState:UIControlStateNormal];
    _launchView.skipBtn.hidden = NO;
}

- (void)scheduledGCDTimer
{
    [self cancleGCDTimer];
    __block int timeLeave = DURATION; //倒计时时间
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    _timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0,queue);
    dispatch_source_set_timer(_timer,dispatch_walltime(NULL, 0),1.0*NSEC_PER_SEC, 0); //每秒执行
    __typeof (self) __weak weakSelf = self;
    dispatch_source_set_event_handler(_timer, ^{
        if(timeLeave <= 0){ //倒计时结束，关闭
            dispatch_source_cancel(weakSelf.timer);
            dispatch_async(dispatch_get_main_queue(), ^{
                //关闭界面
                [self dismissController];
            });
        }else{
            int curTimeLeave = timeLeave;
            dispatch_async(dispatch_get_main_queue(), ^{
                //设置界面
                [weakSelf showSkipBtnTitleTime:curTimeLeave];

            });
            --timeLeave;
        }
    });
    dispatch_resume(_timer);
}

- (void)cancleGCDTimer
{
    if (_timer) {
        dispatch_source_cancel(_timer);
        _timer = nil;
    }
}



#pragma mark - action

- (void)skipADAction {
    [self dismissController];
}

- (void)dismissController
{
    [self cancleGCDTimer];
    //消失动画
    [UIView animateWithDuration:0.0 delay:0.0 options:UIViewAnimationOptionCurveEaseOut animations:^{
        //缩放修改处
        self.transform = CGAffineTransformMakeScale(1, 1);
        self.alpha = 0.0;
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
}
-(void)pushAdController
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [self removeFromSuperview];
      if (self.tapClick) {
            self.tapClick();
        }
    });
}

- (CGFloat)skipBtnHeight {
    if (_skipBtnHeight == 0.00) {
        return kSkipBtnHeight;
    }
    return _skipBtnHeight;
}

- (CGFloat)skipBtnWidth {
    if (_skipBtnWidth == 0.00) {
        return kSkipBtnWidth;
    }
    return _skipBtnWidth;
}

- (CGFloat)skipRightEdging {
    if (_skipRightEdging == 0.00) {
        return kSkipRightEdging;
    }
    return _skipRightEdging;
}

- (CGFloat)skipTopEdging {
    if (_skipTopEdging == 0.00) {
        return kSkipTopEdging;
    }
    return _skipTopEdging;
}

- (CGFloat)imageViewHeight {
    if (_imageViewHeight == 0.00) {
        return kAdImageViewHeight;
    }
    return _imageViewHeight;
}

- (void)dealloc
{
    [self cancleGCDTimer];
}
-(void)show {
    [self addADLaunchView];
    [self loadData];
}
@end
