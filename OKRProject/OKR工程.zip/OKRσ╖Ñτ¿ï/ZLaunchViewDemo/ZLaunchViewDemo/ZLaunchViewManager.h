//
//  ZLaunchViewManager.h
//  ZLaunchViewDemo
//
//  Created by zhaixingxing on 2020/6/2.
//  Copyright © 2020 zhaixingxing. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


//广告倒计时间 单位：秒
#define DURATION 20

NS_ASSUME_NONNULL_BEGIN

@interface ZLaunchViewManager : UIView

/// 跳过按钮宽
@property (nonatomic, assign) CGFloat skipBtnWidth;
/// 跳过按钮高
@property (nonatomic, assign) CGFloat skipBtnHeight;
/// 跳过按钮顶部边距
@property (nonatomic, assign) CGFloat skipRightEdging;
/// 跳过按钮顶部边距
@property (nonatomic, assign) CGFloat skipTopEdging;
/// 图片页面高度
@property (nonatomic, assign) CGFloat imageViewHeight;


/// 点击回调
@property (nonatomic , copy) void(^tapClick) (void);

+ (instancetype)launchViewManger;


/// 展示对象
/// @param view 显示的superView
-(void)showView:(UIView *)view;


@end

NS_ASSUME_NONNULL_END
