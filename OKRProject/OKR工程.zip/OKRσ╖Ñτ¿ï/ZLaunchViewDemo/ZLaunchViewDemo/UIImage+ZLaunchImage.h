//
//  UIImage+ZLaunchImage.h
//  ZLaunchViewDemo
//
//  Created by zhaixingxing on 2020/6/2.
//  Copyright © 2020 zhaixingxing. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIImage (ZLaunchImage)


/// 通过LaunchScreen.StoryBoard加载的本地图片
+ (UIImage *)getLaunchImageWithStordboard;

/// LaunchImage 获取的本地图片
+ (UIImage *)getLaunchImage;


@end

NS_ASSUME_NONNULL_END
