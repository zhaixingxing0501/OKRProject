//
//  ZLaunchView.h
//  ZLaunchViewDemo
//
//  Created by zhaixingxing on 2020/6/2.
//  Copyright © 2020 zhaixingxing. All rights reserved.
//

#import <UIKit/UIKit.h>

#pragma mark -- 默认值 --
//跳过按钮宽
#define kSkipBtnWidth 65
//跳过按钮高
#define kSkipBtnHeight 30
//跳过按钮右边距
#define kSkipRightEdging 20
//跳过按钮顶部边距
#define kSkipTopEdging 40
//默认广告页面高度
#define kAdImageViewHeight CGRectGetHeight([UIScreen mainScreen].bounds)-150

NS_ASSUME_NONNULL_BEGIN

@interface ZLaunchView : UIView

@property (nonatomic, weak) UIImageView *launchImageView;

@property (nonatomic, weak) UIImageView *adImageView;

@property (nonatomic, weak) UIButton *skipBtn;

@end

NS_ASSUME_NONNULL_END
