//
//  ViewController.m
//  ZLaunchViewDemo
//
//  Created by zhaixingxing on 2020/6/2.
//  Copyright © 2020 zhaixingxing. All rights reserved.
//

#import "ViewController.h"
#import "UIImageView+WebCache.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    self.title = @"主页";
    self.view.backgroundColor = UIColor.whiteColor;
    
    UIImageView *v = [[UIImageView alloc] initWithFrame:self.view.bounds];
    [self.view addSubview:v];
    
    [v sd_setImageWithURL:[NSURL URLWithString:@""] completed:^(UIImage * _Nullable image, NSError * _Nullable error, SDImageCacheType cacheType, NSURL * _Nullable imageURL) {
        
    }];
}


@end
