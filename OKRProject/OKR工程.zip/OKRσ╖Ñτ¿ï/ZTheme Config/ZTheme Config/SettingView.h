//
//  SettingView.h
//  ZTheme Config
//
//  Created by zhaixingxing on 2020/6/30.
//  Copyright © 2020 zhaixingxing. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SettingView : UIView
{
    NSMutableArray *themeBtnArry;
}

@end

NS_ASSUME_NONNULL_END
