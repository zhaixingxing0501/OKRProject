//
//  SceneDelegate.h
//  ZTheme Config
//
//  Created by zhaixingxing on 2020/6/18.
//  Copyright © 2020 zhaixingxing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

