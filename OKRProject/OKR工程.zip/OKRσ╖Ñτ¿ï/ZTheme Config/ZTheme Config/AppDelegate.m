//
//  AppDelegate.m
//  ZTheme Config
//
//  Created by zhaixingxing on 2020/6/18.
//  Copyright © 2020 zhaixingxing. All rights reserved.
//

#import "AppDelegate.h"
#import "TKThemeConfig.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    [self changeThemeCofingFllowSystem:YES];
    
    return YES;
}
#pragma mark -- 程序加载完毕 在其它组件含有UI元素前，优先设置主题 ，因为主题作用全局的UI
- (void)changeThemeCofingFllowSystem:(BOOL)fllowSystemTheme{
    if (fllowSystemTheme) {
        //followSystemTheme 一旦设置YES themeIndex便失去作用 因为跟随系统变更。注释见TKThemeManager.h
        [TKThemeManager config].followSystemTheme=YES;
    }else{
        //followSystemTheme 一旦设置NO themeIndex起作用.注释见TKThemeManager.h
        [TKThemeManager config].followSystemTheme=NO;
        [TKThemeManager config].themeIndex = 0;
    }
    
}

#pragma mark - UISceneSession lifecycle


- (UISceneConfiguration *)application:(UIApplication *)application configurationForConnectingSceneSession:(UISceneSession *)connectingSceneSession options:(UISceneConnectionOptions *)options {
    // Called when a new scene session is being created.
    // Use this method to select a configuration to create the new scene with.
    return [[UISceneConfiguration alloc] initWithName:@"Default Configuration" sessionRole:connectingSceneSession.role];
}


- (void)application:(UIApplication *)application didDiscardSceneSessions:(NSSet<UISceneSession *> *)sceneSessions {
    // Called when the user discards a scene session.
    // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
    // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
}


@end
