//
//  UIWindow+TKUpdate.h
//  Pods
//
//  Created by Tkoul on 2020/6/2.
//



#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN

@interface UIWindow (TKUpdate)

@end

NS_ASSUME_NONNULL_END
