//
//  ViewController.m
//  ZWKWebview
//
//  Created by zhaixingxing on 2020/5/27.
//  Copyright © 2020 zhaixingxing. All rights reserved.
//

#import "ViewController.h"
#import <WebKit/WebKit.h>
#import "BaseWKWebViewController.h"

@interface ViewController ()<WKUIDelegate, WKNavigationDelegate, WKScriptMessageHandler>
@property (nonatomic, strong) WKWebView *wkWebView;
@property (nonatomic, strong) UIProgressView *progressView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
//    self.urlStr = @"https://id.nucarf.%@/user/userAgreement";
//    
//    WKWebViewConfiguration* configuration = [[WKWebViewConfiguration alloc] init];
//    configuration.userContentController = [WKUserContentController new];
//    
//    WKPreferences* preferences = [WKPreferences new];
//    preferences.javaScriptCanOpenWindowsAutomatically = YES;
//    configuration.preferences = preferences;
//    
//    NSString* cookieStr = [NSString stringWithFormat:@"%@=%@", @"n-token", @"cookie"];
//    NSString* source = [NSString stringWithFormat:@"document.cookie = '%@;path=/';", cookieStr];
//    WKUserScript *cookieScript = [[WKUserScript alloc] initWithSource:source injectionTime:WKUserScriptInjectionTimeAtDocumentStart forMainFrameOnly:NO];
//    [configuration.userContentController addUserScript:cookieScript];
//    
//    [configuration.userContentController addScriptMessageHandler:self name:@"onReceiveEventFromHtml5"];
//    
//    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:self.urlStr]];
//    
//    // 应用于 request 的 cookie 设置
//    NSDictionary *headFields = request.allHTTPHeaderFields;
//    NSString *cookie = headFields[@"user"];
//    if (cookie == nil) {
//        [request addValue:cookieStr forHTTPHeaderField:@"Cookie"];
//    }
//    
//    WKWebView* webView = [[WKWebView alloc] initWithFrame:self.view.bounds configuration:configuration];
//    
//    webView.UIDelegate = self;
//    webView.navigationDelegate = self;
//    
//    [self.view addSubview:webView];
//    [webView loadRequest:request];
//    self.wkWebView = webView;
//    [self.view addSubview:self.progressView];
//    [webView addObserver:self
//              forKeyPath:@"estimatedProgress"
//                 options:NSKeyValueObservingOptionNew
//                 context:nil];
    
}

- (IBAction)AC1:(id)sender {
    
    BaseWKWebViewController *web = [[BaseWKWebViewController alloc] init];
    web.urlStr  =  @"https://id.nucarf.cn/user/userAgreement";
//    web.modalPresentationStyle =  0
    [self presentViewController:web animated:YES completion:nil];
}
- (IBAction)ac2:(id)sender {
    
    //https://www.baidu.com
    
    BaseWKWebViewController *web = [[BaseWKWebViewController alloc] init];
    web.urlStr  =  @"https://www.baidu.com";
//    [self.navigationController  pushViewController:web animated:YES];
    [self presentViewController:web animated:YES completion:nil];
}

- (IBAction)ac3:(id)sender {
}


- (void)removeWKwebviewCache {
    
    NSString *libraryPath = [NSSearchPathForDirectoriesInDomains(NSLibraryDirectory,NSUserDomainMask,YES) objectAtIndex:0];
    
    NSString *cookiesFolderPath = [libraryPath stringByAppendingString:@"/Cookies"];
    
    NSError *errors;
    [[NSFileManager defaultManager] removeItemAtPath:cookiesFolderPath error:&errors];
    
}

#pragma mark - WKNavigationDelegate

- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation {
    //    self.title = webView.title;
    NSLog(@"网页标题:%@", webView.title);
}

- (void)webView:(WKWebView *)webView didCommitNavigation:(WKNavigation *)navigation {
    [webView evaluateJavaScript:@"document.cookie" completionHandler:^(NSString *result, NSError * _Nullable error) {
        NSLog(@"网页中的cookie为：\n%@",[result componentsSeparatedByString:@"; "]);
    }];
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation {
    
    NSString *injectionJSString = @"var script = document.createElement('meta');"
    "script.name = 'viewport';"
    "script.content=\"width=device-width, user-scalable=no\";"
    "document.getElementsByTagName('head')[0].appendChild(script);";
    [webView evaluateJavaScript:injectionJSString completionHandler:nil];
    
    [webView evaluateJavaScript:@"onNucarfLoaded()" completionHandler:^(id _Nullable obj, NSError * _Nullable error) {
        NSLog(@"OC执行js 的onNucarfLoaded 方法");
    }];
    
    //注入H5 调用 app 方法
    NSString *jsString = @"function sendEventToNative(name, object){"
    "window.webkit.messageHandlers.onReceiveEventFromHtml5.postMessage([name, object]);"//接受对象为数组
    "}";
    [webView evaluateJavaScript:jsString completionHandler:^(id _Nullable obj, NSError * _Nullable error) {
        NSLog(@"OC注入 H5 调取原生方法");
    }];
    
    
    //    [webView evaluateJavaScript:@"sendEventToNative('testDatat')" completionHandler:^(id _Nullable obj, NSError * _Nullable error) {
    //           NSLog(@"H5 调取原生注入方法");
    //         }];
    
    
}
- (void)webView:(WKWebView *)webView runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(void))completionHandler
{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:message
                                                                             message:nil
                                                                      preferredStyle:UIAlertControllerStyleAlert];
    [alertController addAction:[UIAlertAction actionWithTitle:@"OK"
                                                        style:UIAlertActionStyleCancel
                                                      handler:^(UIAlertAction *action) {
        completionHandler();
    }]];
    [self presentViewController:alertController animated:YES completion:^{}];
}


- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(WKNavigation *)navigation withError:(NSError *)error {
    NSLog(@"%s", __FUNCTION__);
    NSLog(@"%@",error);
}

//! WKWeView在每次加载请求前会调用此方法来确认是否进行请求跳转
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler {
    NSString *url = navigationAction.request.URL.absoluteString;
    NSLog(@"加载url:%@", url);
    decisionHandler(WKNavigationActionPolicyAllow);
    
}


- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message {
    // 接受H5发送的事件
    if ([message.name isEqualToString:@"onReceiveEventFromHtml5"]) {
        NSLog(@"H5发送的事件:%@", message.body);
        [self  onReceiveEventFromHtml5WithMeassage:message.body];
    }
}

- (void)onReceiveEventFromHtml5WithMeassage:(id)params {
    
    if ([params isKindOfClass:[NSArray class]]) {
        NSArray *arr =  (NSArray *)params;
        if (arr.count > 0) {
            NSString *methodName = [arr firstObject];
            
            if ([methodName isEqualToString:@"closeWebView"]) {
                
                [self closeWebView];
                
            } else if ([methodName isEqualToString:@"logout"]) {
                
                [self logout];
                
            } else {
                NSLog(@"APP找不到对于方法:%@", params);
            }
            
        }
    }
    
}




- (void)onReceiveEventFromHtml5WithMeassage:(NSString *)name body:(id)body {
    
    if ([body isKindOfClass:[NSString class]] && body) {
        NSString *bodyString = (NSString *)body;
        if ([bodyString isEqualToString:@"closeWebView"]) {
            [self closeWebView];
        } else if ([bodyString isEqualToString:@"goBack"]) {
            if ([self.wkWebView canGoBack]) {
                [self.wkWebView goBack];
            }
        } else if ([bodyString isEqualToString:@"goForward"]) {
            if ([self.wkWebView canGoForward]) {
                [self.wkWebView goForward];
            }
        }
    }
}
#pragma mark -- 退出登录方法 --
- (void)logout {
    //     [RequestDataBase pushLoginVC];
}

#pragma mark -- 关闭webView --
- (void)closeWebView {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark -- 返回方法 --
- (void)backBtnClicked{
    if ([self.wkWebView canGoBack]) {
        [self.wkWebView goBack];
    } else {
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)observeValueForKeyPath:(NSString *)keyPath
                      ofObject:(id)object
                        change:(NSDictionary<NSString *,id> *)change
                       context:(void *)context
{
    if ([keyPath isEqualToString:@"estimatedProgress"]) {
        
        self.progressView.progress = self.wkWebView.estimatedProgress;
        // 加载完成
        if (self.wkWebView.estimatedProgress  >= 1.0f ) {
            
            [UIView animateWithDuration:0.25f animations:^{
                self.progressView.alpha = 0.0f;
                self.progressView.progress = 0.0f;
            }];
            
        }else{
            self.progressView.alpha = 1.0f;
        }
    }
}



- (UIProgressView *)progressView {
    if(!_progressView) {
        _progressView = [[UIProgressView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 0)];
        _progressView.progressViewStyle = UIProgressViewStyleBar;
        _progressView.tintColor = UIColor.greenColor;
        _progressView.trackTintColor = [UIColor clearColor];
    }
    return _progressView;
}

- (void)dealloc {
    [self.wkWebView removeObserver:self forKeyPath:@"estimatedProgress"];
}


@end
